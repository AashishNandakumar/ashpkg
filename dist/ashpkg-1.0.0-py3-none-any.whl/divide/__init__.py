# this is a dependency file
# this helps Python look for the available modules in the packge directory
# also used to mark the directory on the disk as a Python package
from .divide_by_three import divide_by_three
